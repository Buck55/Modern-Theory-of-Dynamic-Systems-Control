% Створення базової системи
s = tf('s');
W_pz = 1.1 / (0.3*s^3 + 4*s^2 + s + 1); % Правильна ПФ

% --- 1. Дослідження впливу параметра T (при k=1) ---
T_base = 20;
W_zz_base = 1 + 1/(T_base*s);
W_zz_inc = 1 + 1/((T_base*2)*s); % T = 40
W_zz_dec = 1 + 1/((T_base/2)*s); % T = 10

sys_T_base = feedback(W_pz, W_zz_base);
sys_T_inc = feedback(W_pz, W_zz_inc);
sys_T_dec = feedback(W_pz, W_zz_dec);

figure;
step(sys_T_base, sys_T_inc, sys_T_dec, 150); % Час моделювання 150с
title('Вплив параметра T на перехідну характеристику');
legend('T = 20 (Початковий)', 'T = 40 (Збільшений удвічі)', 'T = 10 (Зменшений удвічі)');
grid on;

% --- 2. Дослідження впливу параметра k (при T=20) ---
k_base = 1;
W_zz_k_base = k_base + 1/(20*s);
W_zz_k_inc = (k_base*2) + 1/(20*s); % k = 2
W_zz_k_dec = (k_base/2) + 1/(20*s); % k = 0.5

sys_k_base = feedback(W_pz, W_zz_k_base);
sys_k_inc = feedback(W_pz, W_zz_k_inc);
sys_k_dec = feedback(W_pz, W_zz_k_dec);

figure;
step(sys_k_base, sys_k_inc, sys_k_dec, 150);
title('Вплив параметра k на перехідну характеристику');
legend('k = 1 (Початковий)', 'k = 2 (Збільшений удвічі)', 'k = 0.5 (Зменшений удвічі)');
grid on;