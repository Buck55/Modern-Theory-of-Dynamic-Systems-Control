% Задання діапазону частот
w = 0.0001:0.001:5;
p = 1i.*w;

% Передавальні функції прямого (Wsc) та зворотного (Wrc) зв'язків
Wsc = 1.1 ./ (0.3.*p.^3 + 4.*p.^2 + 1.*p + 1); % Виправлено знаменник
Wrc = (1 + 20.*p) ./ (20.*p);

% Передавальна функція замкненої системи
W = Wsc ./ (1 + (Wsc .* Wrc));

% Виділення дійсної та уявної частин, розрахунок амплітуди
Re = real(W);
Im = imag(W);
A = sqrt(Re.^2 + Im.^2);

% Розрахунок фази 
phi = zeros(1, length(w));
for i = 1:length(phi)
    if Re(1,i) > 0 && Im(1,i) < 0
        phi(1,i) = -atan(abs(Im(1,i)./Re(1,i)));
    elseif Re(1,i) < 0 && Im(1,i) < 0
        phi(1,i) = -pi + atan(abs(Im(1,i)./Re(1,i)));
    elseif Re(1,i) < 0 && Im(1,i) > 0
        phi(1,i) = pi - atan(abs(Im(1,i)./Re(1,i)));
    else
        phi(1,i) = atan(abs(Im(1,i)./Re(1,i)));
    end
end

% 1. Побудова АФЧХ (Годограф)
figure('Name', 'АФЧХ', 'NumberTitle', 'off');
plot(Re, Im, 'b', 'LineWidth', 1.5);
title('АФЧХ');
xlabel('Re(\omega)');
ylabel('Im(\omega)');
grid on;

% 2. Побудова АЧХ
figure('Name', 'АЧХ', 'NumberTitle', 'off');
plot(w, A, 'r', 'LineWidth', 1.5);
title('АЧХ');
xlabel('\omega');
ylabel('A(\omega)');
grid on;

% 3. Побудова ФЧХ
figure('Name', 'ФЧХ', 'NumberTitle', 'off');
plot(w, phi, 'g', 'LineWidth', 1.5);
title('ФЧХ');
xlabel('\omega');
ylabel('\phi(\omega)');
grid on;