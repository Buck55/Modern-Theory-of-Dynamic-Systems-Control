% === 1. ВИХІДНІ ДАНІ ===
D = [1, 3, 33, 35, 14, 10]; % Коефіцієнти a5, a4, a3, a2, a1, a0
num = 16; % b0

% === 2. ЗНАХОДЖЕННЯ ПОЛЮСІВ ТА МЕЖІ СТІЙКОСТІ ===
poles = roots(D);
disp('Початкові полюси (корені) системи:'); disp(poles);

new_poles = poles;
for i = 1:length(new_poles)
    if ~isreal(new_poles(i))
        new_poles(i) = 1i * imag(new_poles(i)); % Обнуляємо дійсну частину
    end
end
D_new = poly(new_poles); % Нове характеристичне рівняння на межі стійкості
disp('Коефіцієнти нового рівняння на межі стійкості:'); disp(real(D_new));

% === 3. ГОДОГРАФ МИХАЙЛОВА ===
w_m = 0:0.01:10;
p_m = 1i * w_m;
M_init = polyval(D, p_m);
M_bound = polyval(D_new, p_m);

figure('Name', 'Критерій Михайлова', 'NumberTitle', 'off');
plot(real(M_init), imag(M_init), 'b', 'LineWidth', 1.5); hold on; grid on;
plot(real(M_bound), imag(M_bound), 'r--', 'LineWidth', 1.5);
title('Годограф Михайлова');
xlabel('U(\omega)'); ylabel('V(\omega)');
legend('Початкова система', 'Система на межі стійкості');
plot(0, 0, 'kx', 'MarkerSize', 8, 'LineWidth', 2);
axis([-50 50 -50 50]); % Масштабування для зручності

% === 4. ПОРІВНЯЛЬНІ ХАРАКТЕРИСТИКИ ДЛЯ 3-Х ПАРАМЕТРІВ ===
W_pz = tf(num, D); % Передавальна функція
k1 = 1; k2 = 2; k3 = 0.5; % Три значення k
w_bode = logspace(-2, 2, 1000);

% АФЧХ (Найквіст)
figure('Name', 'Порівняльна АФЧХ', 'NumberTitle', 'off'); hold on; grid on;
[re1, im1] = nyquist(k1*W_pz, w_bode);
[re2, im2] = nyquist(k2*W_pz, w_bode);
[re3, im3] = nyquist(k3*W_pz, w_bode);
plot(squeeze(re1), squeeze(im1), 'b', 'LineWidth', 1.5);
plot(squeeze(re2), squeeze(im2), 'r', 'LineWidth', 1.5);
plot(squeeze(re3), squeeze(im3), 'g', 'LineWidth', 1.5);
plot(-1, 0, 'k+', 'MarkerSize', 10, 'LineWidth', 2); % Критична точка
title('АФЧХ для різних k (Критерій Найквіста)');
xlabel('Re'); ylabel('Im');
legend('k=1 (Початковий)', 'k=2 (Збільшений)', 'k=0.5 (Зменшений)', 'Точка (-1, j0)');
axis([-2 2 -2 2]);

% ФЧХ (Фаза)
figure('Name', 'Порівняльна ФЧХ', 'NumberTitle', 'off'); hold on; grid on;
[~, ph1] = bode(k1*W_pz, w_bode);
[~, ph2] = bode(k2*W_pz, w_bode);
[~, ph3] = bode(k3*W_pz, w_bode);
semilogx(w_bode, squeeze(ph1), 'b-', 'LineWidth', 4);
semilogx(w_bode, squeeze(ph2), 'r--', 'LineWidth', 2.5);
semilogx(w_bode, squeeze(ph3), 'g:', 'LineWidth', 1.5);
title('ФЧХ розімкненої системи');
xlabel('Частота (рад/с)'); ylabel('Фаза (градуси)');
legend('k=1', 'k=2', 'k=0.5');