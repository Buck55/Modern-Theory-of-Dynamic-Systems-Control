% Лабораторна робота №5. Варіант 16
clear; clc; close all;

% --- 1. ПАРАМЕТРИ СИСТЕМИ ---
a3 = 14; a2 = 30; a1 = 15; a0 = 0; % a0 = 0 (інтегруюча властивість)
b2 = 0;  b1 = 0;  b0 = 4;
T = 20;

% Передавальні функції
s = tf('s');
W_ob = (b2*s^2 + b1*s + b0) / (a3*s^3 + a2*s^2 + a1*s + a0);

% --- 2. ПОБУДОВА КРИВОЇ Д-РОЗБИТТЯ ---
w = 0:0.001:1.5; % Діапазон частот
jw = 1i * w;
% Рівняння: k = -1/W_ob(jw) - 1/(T*jw)
W_ob_jw = 4 ./ (14*(jw).^3 + 30*(jw).^2 + 15*jw);
k_D = -1 ./ W_ob_jw - 1 ./ (T * jw);

figure('Name', 'Д-розбиття', 'NumberTitle', 'off');
plot(real(k_D), imag(k_D), 'b', 'LineWidth', 1.5); hold on;
plot(real(k_D), -imag(k_D), 'b--', 'LineWidth', 1.5); % Симетрична гілка
grid on;
xlabel('Re(k)'); ylabel('Im(k)');
title('Крива Д-розбиття для параметра k');
xline(0.101, 'g', 'k_min \approx 0.101', 'LineWidth', 1.5);
xline(7.935, 'r', 'k_max \approx 7.935', 'LineWidth', 1.5);

% --- 3. КРИТЕРІЙ НАЙКВІСТА (для k=1) ---
k_stable = 1;
W_reg_stable = k_stable + 1/(T*s);
W_roz_stable = W_reg_stable * W_ob;

figure('Name', 'Критерій Найквіста', 'NumberTitle', 'off');
nyquist(W_roz_stable);
grid on;
title('Годограф Найквіста розімкненої системи (при k=1)');

% --- 4. МОДЕЛЮВАННЯ ПЕРЕХІДНИХ ПРОЦЕСІВ ---
k_bound = 7.935; % На межі стійкості
W_reg_bound = k_bound + 1/(T*s);

% Замкнені системи
W_zam_stable = feedback(W_roz_stable, 1);
W_zam_bound = feedback(W_reg_bound * W_ob, 1);

figure('Name', 'Перехідні процеси', 'NumberTitle', 'off');
step(W_zam_stable, 100); hold on;
step(W_zam_bound, 100);
grid on;
legend('Стійка система (k=1)', 'На межі стійкості (k=7.935)');
title('Реакція системи на одиничний стрибок');
ylabel('Амплітуда'); xlabel('Час (с)');